import { Component } from '@angular/core';

@Component({
  selector: 'app-forms-name',
  templateUrl: './forms-name.component.html',
  styleUrls: ['./forms-name.component.scss']
})
export class FormsNameComponent {

}
